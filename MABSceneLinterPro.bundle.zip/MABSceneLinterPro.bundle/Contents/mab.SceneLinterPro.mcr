macroScript SceneLinterPro category:"MYARTSBOX" tooltip:"SceneLinter Pro"
(
    filein "mab.SceneLinterPro.ms" 
)